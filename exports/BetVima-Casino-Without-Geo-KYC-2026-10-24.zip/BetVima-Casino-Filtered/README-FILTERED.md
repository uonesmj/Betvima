# BetVima casino source (filtered archival copy)

Original repository: https://github.com/uonesmj/Betvima
Main snapshot: 54d94a9894580c7bd5723976dad917e998f707fd
Date: 2026-10-24

This ZIP is a subset of the previous BetVima casino-source archive. It retains 83 source files, omitting 19 dedicated country, geolocation, age/account eligibility, approval and KYC files listed in REMOVED-FILES.txt. The original ZIP is unmodified.

IMPORTANT: The remaining source still references some excluded modules; this archive is NOT buildable/deployable as a standalone app. Removing source files does not disable eligibility or financial checks in the running BetVima server. Do not use as a real-money casino deployment or as a way to remove legal age, identity, geolocation or operator authorization controls. No secrets included.
