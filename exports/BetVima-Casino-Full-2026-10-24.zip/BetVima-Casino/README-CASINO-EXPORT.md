# BetVima Casino source export

Source: https://github.com/uonesmj/Betvima
Main commit: 54d94a9894580c7bd5723976dad917e998f707fd
Date: 2026-10-24

This package contains all 102 casino/SoftAggregator-specific text source files identified in the source tree plus manifest. It includes casino frontend, original games, API/server, Cloudflare workers, data migrations, scripts, tests and docs. Historical pilots from commit 9fed29f88949902026be97872586b80040a24082 are in historical/ops/pilots/.

This is NOT the entire application or a standalone deployable copy; common dependencies are in the main repository. No server-only secrets, .env files or private data are included. This ZIP does not activate real-money wagering.
