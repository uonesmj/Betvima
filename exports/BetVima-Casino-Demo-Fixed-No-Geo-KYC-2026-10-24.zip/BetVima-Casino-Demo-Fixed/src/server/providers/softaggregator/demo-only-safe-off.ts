/**
 * Compatibility stubs for the filtered, DEMO-ONLY source archive.
 * Dedicated account-approval and country/geo files were intentionally omitted.
 * Every real-money capability must fail closed.
 * This file is NOT a replacement for real-money eligibility and MUST NOT
 * be deployed as a substitute for licensing, age verification or geo controls.
 */
export function casinoCountryPermitted(_country: string | null, _configured?: string): boolean {
  return false;
}
export const CASINO_SUPPORT_APPROVAL_SQL = 'false';
export function casinoManualReviewRequired(): boolean {
  return true;
}
export async function casinoManualReviewSatisfied(_userId: string): Promise<boolean> {
  return false;
}
export function verifiedCasinoLocation(_request: Request): string | null {
  return null;
}
