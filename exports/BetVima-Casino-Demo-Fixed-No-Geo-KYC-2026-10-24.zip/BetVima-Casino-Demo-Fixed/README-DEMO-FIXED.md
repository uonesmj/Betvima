# BetVima casino filtered demo-only compatibility export

Date: 2026-10-24
Source: https://github.com/uonesmj/Betvima (main snapshot 54d94a9894580c7bd5723976dad917e998f707fd)

This source-only ZIP contains 81 casino-related files, excludes 22 dedicated country/location, KYC/account approval and related cash-only integration-test files, and has 8 modified/new files. See REMOVED-FILES.txt and MODIFIED-FILES.txt.

Changes: a new demo-only-safe-off.ts fail-closed compatibility module replaces missing country/account verification imports; casinoRealMoneyEnabled() unconditionally returns false, so neither environment flags nor player access can enable cash. The Casino UI no longer polls the removed eligibility endpoint, and the pilot-test workflow no longer names a removed test.

This ZIP is for editing and studying the demo only. It is NOT safe or permitted for real-money wagering. Removing compliance modules from production would break integrity and operator obligations. Do not deploy it to the live BetVima server. No real-money funds, keys, VPS .env files or accounts were included.

STATIC CHECK: No remaining import refers to the deleted 19 modules. Full npm/TypeScript build/tests were NOT executed. Shared dependencies from the original full repository are still required; this ZIP is NOT a standalone runnable app.
